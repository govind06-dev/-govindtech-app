# GovindTech - Electronics E-Commerce Platform

A cloud-based secure e-commerce web application built with DevSecOps best practices on AWS.

## Live URL
https://govindtech.duckdns.org

## Tech Stack
- **Backend:** Node.js + Express.js
- **Frontend:** HTML5 + CSS3 + Vanilla JS
- **Database:** MySQL 8.0 (AWS RDS)
- **Web Server:** Nginx (reverse proxy)
- **Cloud:** AWS (EC2, RDS, S3, ALB, CloudFront, CloudWatch)
- **CI/CD:** GitHub Actions
- **Container:** Docker
- **Monitoring:** AWS CloudWatch + SNS

## Project Structure
```
govindtech/
├── src/
│   ├── app.js              # Main Express application
│   ├── config/
│   │   ├── db.js           # MySQL database connection
│   │   └── logger.js       # Winston logger
│   ├── middleware/
│   │   └── auth.js         # JWT auth middleware
│   ├── models/
│   │   └── schema.sql      # Database schema + seed data
│   └── routes/
│       ├── auth.js         # Register, login, profile
│       ├── products.js     # Product CRUD
│       ├── orders.js       # Order management
│       └── admin.js        # Admin stats & user management
├── public/
│   └── index.html          # Complete SPA frontend
├── scripts/
│   ├── server-setup.sh     # One-click server setup
│   ├── backup.sh           # Automated S3 backup
│   ├── nginx.conf          # Nginx reverse proxy config
│   ├── cloudwatch-config.json  # CloudWatch agent config
│   └── logrotate.conf      # Log rotation config
├── .github/
│   └── workflows/
│       └── deploy.yml      # GitHub Actions CI/CD
├── Dockerfile
├── .env.example
└── README.md
```

## Quick Setup

### 1. Clone Repository
```bash
git clone https://github.com/[your-username]/govindtech.git
cd govindtech
```

### 2. Setup Server (run once on EC2)
```bash
bash scripts/server-setup.sh
```

### 3. Configure Environment
```bash
cp .env.example .env
nano .env   # Fill in your RDS endpoint, JWT secret, S3 bucket, etc.
```

### 4. Setup Database
```bash
mysql -h [RDS_ENDPOINT] -u admin -p govindtech < src/models/schema.sql
```

### 5. Install & Start App
```bash
npm install --production
pm2 start src/app.js --name govindtech-app
pm2 save && pm2 startup
```

### 6. Configure Nginx + HTTPS
```bash
sudo cp scripts/nginx.conf /etc/nginx/sites-available/govindtech
sudo ln -s /etc/nginx/sites-available/govindtech /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d govindtech.duckdns.org
```

### 7. Setup CloudWatch Monitoring
```bash
sudo cp scripts/cloudwatch-config.json /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json
```

### 8. Setup Automated Backups
```bash
chmod +x scripts/backup.sh
crontab -e
# Add: 0 2 * * * /home/ubuntu/govindtech/scripts/backup.sh
```

## Default Admin Credentials
- Email: `admin@govindtech.com`
- Password: `Admin@123`

> **Change the admin password immediately after first login!**

## API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/auth/register | None | Register user |
| POST | /api/auth/login | None | Login |
| GET | /api/auth/profile | User | Get profile |
| GET | /api/products | None | List products |
| GET | /api/products/:id | None | Get product |
| POST | /api/products | Admin | Add product |
| PUT | /api/products/:id | Admin | Edit product |
| DELETE | /api/products/:id | Admin | Delete product |
| POST | /api/orders | User | Place order |
| GET | /api/orders/my-orders | User | My orders |
| GET | /api/orders | Admin | All orders |
| PUT | /api/orders/:id/status | Admin | Update status |
| GET | /api/admin/stats | Admin | Dashboard stats |
| GET | /api/admin/users | Admin | All users |
| DELETE | /api/admin/users/:id | Admin | Delete user |
| GET | /health | None | Health check |

## Security Features
- HTTPS with Let's Encrypt SSL
- JWT Authentication (24hr expiry)
- bcrypt password hashing (12 salt rounds)
- SQL injection prevention (parameterized queries)
- XSS protection (Helmet.js + input sanitization)
- API rate limiting (100 req/15min general, 5 req/15min login)
- Security headers (X-Frame-Options, CSP, HSTS, etc.)
- Failed login attempt logging to CloudWatch

## GitHub Secrets Required
| Secret | Description |
|--------|-------------|
| EC2_SSH_KEY | Private SSH key (.pem contents) |
| BASTION_HOST | Bastion host public IP |
| EC2_PRIVATE_IP | App server private IP |

---
**Govind | DevSecOps Capstone Project | IPSR Solutions Ltd**
