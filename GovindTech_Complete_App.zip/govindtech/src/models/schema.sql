CREATE DATABASE IF NOT EXISTS govindtech;
USE govindtech;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user', 'admin') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  stock INT DEFAULT 0,
  category VARCHAR(100) DEFAULT 'Electronics',
  image_url VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  status ENUM('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Default admin user (password: Admin@123)
INSERT IGNORE INTO users (name, email, password_hash, role) VALUES
('Govind Admin', 'admin@govindtech.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMqJqhcanFp8RRnWAdipt2/KO2', 'admin');

-- Sample products
INSERT IGNORE INTO products (name, description, price, stock, category, image_url) VALUES
('iPhone 15 Pro', 'Apple iPhone 15 Pro 256GB - Titanium Black. A17 Pro chip, 48MP camera system.', 134900.00, 10, 'Smartphones', 'https://via.placeholder.com/400x300/1a1a2e/ffffff?text=iPhone+15+Pro'),
('Samsung Galaxy S24 Ultra', 'Samsung Galaxy S24 Ultra 512GB. Snapdragon 8 Gen 3, S Pen included.', 134999.00, 15, 'Smartphones', 'https://via.placeholder.com/400x300/16213e/ffffff?text=Galaxy+S24+Ultra'),
('MacBook Air M2', 'Apple MacBook Air 13-inch M2 chip, 8GB RAM, 256GB SSD.', 114900.00, 8, 'Laptops', 'https://via.placeholder.com/400x300/0f3460/ffffff?text=MacBook+Air+M2'),
('Dell XPS 15', 'Dell XPS 15 Intel Core i7, 16GB RAM, 512GB SSD, 4K OLED display.', 159999.00, 5, 'Laptops', 'https://via.placeholder.com/400x300/533483/ffffff?text=Dell+XPS+15'),
('Sony WH-1000XM5', 'Sony Premium Noise Cancelling Wireless Headphones. 30hr battery.', 29990.00, 20, 'Audio', 'https://via.placeholder.com/400x300/e94560/ffffff?text=Sony+WH-1000XM5'),
('iPad Air M1', 'Apple iPad Air 10.9-inch M1 chip, 64GB WiFi. All-day battery.', 59900.00, 12, 'Tablets', 'https://via.placeholder.com/400x300/1a1a2e/ffffff?text=iPad+Air+M1'),
('OnePlus 12', 'OnePlus 12 256GB. Snapdragon 8 Gen 3, 50MP Hasselblad camera.', 64999.00, 20, 'Smartphones', 'https://via.placeholder.com/400x300/16213e/ffffff?text=OnePlus+12'),
('Apple AirPods Pro 2', 'Apple AirPods Pro 2nd Gen. Active Noise Cancellation, MagSafe case.', 24900.00, 25, 'Audio', 'https://via.placeholder.com/400x300/0f3460/ffffff?text=AirPods+Pro+2');
