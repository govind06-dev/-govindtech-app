const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth, adminOnly } = require('../middleware/auth');
const { logger } = require('../config/logger');

// GET /api/products - list all with search & pagination
router.get('/', async (req, res) => {
  try {
    const { search = '', category = '', page = 1, limit = 8 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    let query = 'SELECT * FROM products WHERE 1=1';
    let countQuery = 'SELECT COUNT(*) as total FROM products WHERE 1=1';
    const params = [];

    if (search) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      countQuery += ' AND (name LIKE ? OR description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }
    if (category) {
      query += ' AND category = ?';
      countQuery += ' AND category = ?';
      params.push(category);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    const [products] = await db.query(query, [...params, parseInt(limit), offset]);
    const [countResult] = await db.query(countQuery, params);

    res.json({ products, total: countResult[0].total, page: parseInt(page), limit: parseInt(limit) });
  } catch (err) {
    logger.error('Get products error', { error: err.message });
    res.status(500).json({ error: 'Server error.' });
  }
});

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Product not found.' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// POST /api/products - admin only
router.post('/', auth, adminOnly, async (req, res) => {
  const { name, description, price, stock, category, image_url } = req.body;
  if (!name || !price) return res.status(400).json({ error: 'Name and price are required.' });
  try {
    const [result] = await db.query(
      'INSERT INTO products (name, description, price, stock, category, image_url) VALUES (?, ?, ?, ?, ?, ?)',
      [name, description || '', price, stock || 0, category || 'Electronics', image_url || '']
    );
    const [newProduct] = await db.query('SELECT * FROM products WHERE id = ?', [result.insertId]);
    logger.info('Product created', { productId: result.insertId, name });
    res.status(201).json(newProduct[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// PUT /api/products/:id - admin only
router.put('/:id', auth, adminOnly, async (req, res) => {
  const { name, description, price, stock, category, image_url } = req.body;
  try {
    await db.query(
      'UPDATE products SET name=?, description=?, price=?, stock=?, category=?, image_url=? WHERE id=?',
      [name, description, price, stock, category, image_url, req.params.id]
    );
    const [updated] = await db.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
    res.json(updated[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// DELETE /api/products/:id - admin only
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    await db.query('DELETE FROM products WHERE id = ?', [req.params.id]);
    logger.info('Product deleted', { productId: req.params.id });
    res.json({ message: 'Product deleted.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
