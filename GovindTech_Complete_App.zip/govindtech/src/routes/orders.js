const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { auth, adminOnly } = require('../middleware/auth');
const { logger } = require('../config/logger');

// POST /api/orders - place order
router.post('/', auth, async (req, res) => {
  const { items } = req.body; // [{product_id, quantity}]
  if (!items || items.length === 0) return res.status(400).json({ error: 'No items in order.' });

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    let total = 0;
    const orderItems = [];

    for (const item of items) {
      const [rows] = await conn.query('SELECT * FROM products WHERE id = ? FOR UPDATE', [item.product_id]);
      if (rows.length === 0) throw new Error(`Product ${item.product_id} not found`);
      const product = rows[0];
      if (product.stock < item.quantity) throw new Error(`Insufficient stock for ${product.name}`);

      total += product.price * item.quantity;
      orderItems.push({ product, quantity: item.quantity, price: product.price });

      await conn.query('UPDATE products SET stock = stock - ? WHERE id = ?', [item.quantity, item.product_id]);
    }

    const [orderResult] = await conn.query(
      'INSERT INTO orders (user_id, total) VALUES (?, ?)',
      [req.user.id, total]
    );
    const orderId = orderResult.insertId;

    for (const item of orderItems) {
      await conn.query(
        'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
        [orderId, item.product.id, item.quantity, item.price]
      );
    }

    await conn.commit();
    logger.info('Order placed', { orderId, userId: req.user.id, total });
    res.status(201).json({ message: 'Order placed successfully!', orderId, total });
  } catch (err) {
    await conn.rollback();
    res.status(400).json({ error: err.message });
  } finally {
    conn.release();
  }
});

// GET /api/orders/my-orders
router.get('/my-orders', auth, async (req, res) => {
  try {
    const [orders] = await db.query(
      'SELECT o.*, GROUP_CONCAT(p.name SEPARATOR ", ") as product_names FROM orders o LEFT JOIN order_items oi ON o.id = oi.order_id LEFT JOIN products p ON oi.product_id = p.id WHERE o.user_id = ? GROUP BY o.id ORDER BY o.created_at DESC',
      [req.user.id]
    );
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// GET /api/orders - admin: all orders
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const [orders] = await db.query(
      'SELECT o.*, u.name as user_name, u.email FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC'
    );
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// PUT /api/orders/:id/status - admin update status
router.put('/:id/status', auth, adminOnly, async (req, res) => {
  const { status } = req.body;
  try {
    await db.query('UPDATE orders SET status = ? WHERE id = ?', [status, req.params.id]);
    res.json({ message: 'Order status updated.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

module.exports = router;
