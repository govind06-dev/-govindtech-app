const winston = require('winston');
const path = require('path');
const fs = require('fs');

const logDir = '/var/log/govindtech';
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: `${logDir}/app.log` }),
    new winston.transports.File({ filename: `${logDir}/error.log`, level: 'error' }),
    new winston.transports.Console({ format: winston.format.simple() })
  ]
});

const securityLogger = winston.createLogger({
  level: 'warn',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: `${logDir}/security.log` }),
    new winston.transports.Console()
  ]
});

module.exports = { logger, securityLogger };
