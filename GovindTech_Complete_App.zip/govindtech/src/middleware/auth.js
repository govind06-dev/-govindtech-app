const jwt = require('jsonwebtoken');
const { securityLogger } = require('../config/logger');

const auth = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    securityLogger.warn('Invalid JWT token attempt', {
      ip: req.ip,
      userAgent: req.get('user-agent')
    });
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
};

const adminOnly = (req, res, next) => {
  if (req.user.role !== 'admin') {
    securityLogger.warn('Unauthorized admin access attempt', {
      userId: req.user.id,
      ip: req.ip
    });
    return res.status(403).json({ error: 'Access denied. Admins only.' });
  }
  next();
};

module.exports = { auth, adminOnly };
