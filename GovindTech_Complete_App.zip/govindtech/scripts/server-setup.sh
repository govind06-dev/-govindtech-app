#!/bin/bash
# GovindTech - Complete Server Setup Script
# Run this on your EC2 Ubuntu 22.04 instance
# Usage: bash server-setup.sh

set -e
echo "========================================"
echo "  GovindTech Server Setup Starting..."
echo "========================================"

# 1. Update system
echo "[1/10] Updating system packages..."
sudo apt update && sudo apt upgrade -y

# 2. Install Node.js 20
echo "[2/10] Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 3. Install Nginx
echo "[3/10] Installing Nginx..."
sudo apt install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx

# 4. Install MySQL client
echo "[4/10] Installing MySQL client..."
sudo apt install -y mysql-client

# 5. Install PM2
echo "[5/10] Installing PM2..."
sudo npm install -g pm2

# 6. Install Certbot
echo "[6/10] Installing Certbot..."
sudo apt install -y certbot python3-certbot-nginx

# 7. Install Docker
echo "[7/10] Installing Docker..."
sudo apt install -y docker.io
sudo systemctl enable docker
sudo systemctl start docker
sudo usermod -aG docker ubuntu

# 8. Install CloudWatch Agent
echo "[8/10] Installing CloudWatch Agent..."
wget https://s3.amazonaws.com/amazoncloudwatch-agent/ubuntu/amd64/latest/amazon-cloudwatch-agent.deb
sudo dpkg -i amazon-cloudwatch-agent.deb
rm amazon-cloudwatch-agent.deb

# 9. Setup UFW Firewall
echo "[9/10] Configuring UFW firewall..."
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable

# 10. Create log directories
echo "[10/10] Creating log directories..."
sudo mkdir -p /var/log/govindtech
sudo chown ubuntu:ubuntu /var/log/govindtech

echo "========================================"
echo "  Server setup complete!"
echo "========================================"
echo ""
echo "Next steps:"
echo "1. Clone your repo: git clone https://github.com/[username]/govindtech.git"
echo "2. cd govindtech && cp .env.example .env && nano .env"
echo "3. mysql -h [RDS_ENDPOINT] -u admin -p govindtech < src/models/schema.sql"
echo "4. npm install --production"
echo "5. pm2 start src/app.js --name govindtech-app && pm2 save && pm2 startup"
echo "6. sudo cp scripts/nginx.conf /etc/nginx/sites-available/govindtech"
echo "7. sudo ln -s /etc/nginx/sites-available/govindtech /etc/nginx/sites-enabled/"
echo "8. sudo nginx -t && sudo systemctl reload nginx"
echo "9. sudo certbot --nginx -d govindtech.duckdns.org"
echo "10. sudo cp scripts/cloudwatch-config.json /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json"
echo "11. sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -s -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json"
echo "12. sudo cp scripts/logrotate.conf /etc/logrotate.d/govindtech"
echo "13. Add cron job: 0 2 * * * /home/ubuntu/govindtech/scripts/backup.sh"
