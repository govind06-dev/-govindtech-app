#!/bin/bash
# GovindTech Automated Backup Script
# Runs daily at 2 AM via cron: 0 2 * * * /home/ubuntu/govindtech/scripts/backup.sh

set -e

source /home/ubuntu/govindtech/.env

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/tmp/govindtech_backup"
LOG_FILE="/var/log/govindtech/backup.log"

echo "[$DATE] Starting backup..." >> $LOG_FILE

mkdir -p $BACKUP_DIR

# Database backup
echo "[$DATE] Backing up database..." >> $LOG_FILE
mysqldump -h $DB_HOST -u $DB_USER -p$DB_PASS $DB_NAME | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# Upload to S3
echo "[$DATE] Uploading to S3..." >> $LOG_FILE
aws s3 cp $BACKUP_DIR/db_$DATE.sql.gz s3://$S3_BUCKET/backups/db/db_$DATE.sql.gz --region $AWS_REGION

# Sync media files
aws s3 sync /home/ubuntu/govindtech/public/uploads s3://$S3_BUCKET/backups/media/ --region $AWS_REGION

# Cleanup old backups (keep 30 days)
aws s3 ls s3://$S3_BUCKET/backups/db/ | while read -r line; do
  createDate=$(echo $line | awk '{print $1" "$2}')
  createDate=$(date -d "$createDate" +%s)
  olderThan=$(date -d "30 days ago" +%s)
  if [[ $createDate -lt $olderThan ]]; then
    fileName=$(echo $line | awk '{print $4}')
    aws s3 rm s3://$S3_BUCKET/backups/db/$fileName
  fi
done

# Cleanup temp
rm -rf $BACKUP_DIR

echo "[$DATE] Backup completed successfully." >> $LOG_FILE
